
/** @type {import('next').NextConfig} */
const nextConfig = {
  trailingSlash: true,
  images: {
    unoptimized: true
  },
  typescript: {
    // ⚠️ Dangerously allow production builds to successfully complete even if
    // your project has TypeScript errors.
    ignoreBuildErrors: true,
  },
  eslint: {
    // Suppress ESLint configuration warnings during build
    ignoreDuringBuilds: false,
  },
  experimental: {
    optimizePackageImports: ['react-i18next']
  },
  
  allowedDevOrigins: ['*'],
  
  // API Proxy disabled - using production API directly
  // async rewrites() {
  //   if (process.env.NODE_ENV === 'development') {
  //     return [
  //       {
  //         source: '/api/:path*',
  //         destination: 'http://localhost:5000/:path*',
  //       },
  //     ];
  //   }
  //   return [];
  // },
  
  // Environment variables
  env: {
    NEXT_PUBLIC_API_URL: 'https://api.daleelbalady.com/api',
    NEXT_PUBLIC_DEV_API_URL: 'https://api.daleelbalady.com/api',
  },
  
  // For RTL support (temporarily disabled for build fix)
  // i18n: {
  //   locales: ['en', 'ar'],
  //   defaultLocale: 'ar',
  //   localeDetection: false,
  // },
  
  // Build ID
  async generateBuildId() {
    return 'daleel-balady-build'
  },
}
 
export default nextConfig
